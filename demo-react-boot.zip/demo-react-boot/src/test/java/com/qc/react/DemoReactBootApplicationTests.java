package com.qc.react;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoReactBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
